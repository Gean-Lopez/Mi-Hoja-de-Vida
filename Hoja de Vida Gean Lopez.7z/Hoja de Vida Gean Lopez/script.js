function mostrarMensaje() {
  alert("¡Hola! Soy Gean Marcos Lopez Recalde y esta es mi hoja de vida.");
}
